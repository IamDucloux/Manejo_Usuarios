﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arreglos
{
    

    public partial class Form1 : Form
    {
       public static string[] usuarios = new string[30];
       public static int[] passwords = new int[30];
       public char[] nUsr = new char[30];
        Boolean bande1 = false;
        char sUsr = ' ';
        Form2 usuF = new Form2();
        Form3 mantF = new Form3();



        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            usuarios[0] = "Luis";
            usuarios[1] = "Arely";
            usuarios[2] = "Bruno";
            passwords[0] = 12345;
            passwords[1] = 54321;
            passwords[2] = 56789;
            nUsr[0] = 'U';
            nUsr[1] = 'M';
            nUsr[2] = 'U';
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sUsr = ' ';
            for (int i = 0; i < 30; i++)
            {
                if (usuarios[i]==textBox1.Text&&passwords[i].ToString()==textBox2.Text)
                {
                    bande1 = true;
                    sUsr = nUsr[i];
                }

                
                
                
                    
                

                

            }

            if (bande1==true)
            {
                MessageBox.Show("Bienvenido "+textBox1.Text);
                if (sUsr=='U')
                {
                    usuF.Show();
                    Hide();
                }
                else
                {
                    mantF.Show();
                    Hide();
                }
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrecta");
                textBox1.Clear();
                textBox2.Clear();
            }

            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
